# 사고실험 진척 관리 설정

- backend: notion
- Notion 페이지 또는 데이터베이스: [Todo](https://app.notion.com/p/3e294f513027804190cbd65f69a529c0)

사고실험을 처음 실행하기 전에 다음 중 하나를 선택한다.

1. `repository` — 각 `04-Projects/thought-experiment-runs/{slug}/progress.md`가 진척 정본이다.
2. `notion` — 연결된 Notion 페이지 또는 데이터베이스가 진척 정본이다. 이 파일에는 Notion 링크·식별자만 기록한다.

이 개인 브랜치는 Notion을 진척 정본으로 선택한다. 사고실험의 상태·결정은 Todo의 `그냥 논문 연구` 섹션에서 관리하고, 로컬에는 가설과 실행 증거만 보관한다.
