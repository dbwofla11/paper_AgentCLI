---
name: daily-digest-loop
description: 매일 논문 후보 3편을 검색해 채팅으로 제시한다. CV·멀티모달·사용자 관심 분야의 학회 발표·게재 논문을 찾을 때 사용한다.
---

# Daily Paper Candidates

한 번 호출하면 Asia/Seoul 기준 날짜의 논문 후보 3편을 찾고 채팅으로만 보고한다. 뉴스 검색, 파일 저장, Keep·인덱스 등록, JSON 생성, Git commit/push는 이 스킬의 실행에 포함하지 않는다. 후보를 채택하면 `paper-search`로 넘긴다.

## 선정

1. 아래 세 슬롯을 각각 한 편씩 채운다.
   - 컴퓨터 비전 (`computer-vision`) 1편
   - 멀티모달 1편. 저장소 카테고리는 논문의 주 입력·태스크·방법에 따라 `computer-vision`, `agent-ai`, `other` 중 하나를 택하고 `multimodal` 토픽 태그를 별도로 둔다.
   - 사용자의 관심 분야 1편. `05-Ideas/thought-experiments/`의 활성 아이디어, `01-Papers/keep.md`, `02-Concepts/`, 최근 리뷰·JSON을 확인해 가장 관련 높은 주제를 선택한다. 이 자료가 비어 있으면 `wifi-csi`, `game-ai`, `agent-ai` 중 최근 다루지 않은 분야를 고른다.
2. `01-Papers/reference/cs-conferences.csv`에서 관련 분야 학회를 참고하고, `paper-search` 절차로 최소 두 학술 소스를 탐색한다. 분야·방법·태스크 용어를 나눠 검색하고, 후보가 겹치면 DOI/arXiv ID 기준으로 합친다.
3. 공식 proceedings, 출판사 논문 페이지 또는 학회 공식 프로그램과 논문 원문으로 발표·게재를 확인한다. arXiv preprint만 확인된 논문은 제외한다. 학회명·연도·논문 유형과 확인 URL을 기록한다.
4. 제목·초록만으로 분야를 확정하지 않는다. 원문에서 실제 입력·태스크·방법을 확인한다. 특히 멀티모달은 둘 이상의 modality가 방법의 핵심인지 확인하며, 단순히 텍스트를 언급하는 논문은 포함하지 않는다.
5. 슬롯의 논문을 검증하지 못하면 다른 분야 논문으로 임의 대체하지 않는다. 부족한 슬롯과 검색 범위를 보고한다.

## 출력과 인계

표에 슬롯·정식 제목·저자·학회/연도/유형·발표 확인 링크·한 줄 요약·관심 분야와의 관련 이유를 제시한다. 이어 [paper-summary](../paper-summary/SKILL.md) 형식으로 각 논문의 초록, 전체 주장, 방법, 한계를 짧게 덧붙이고 실제 확인한 원문 범위를 명시한다.

후보 목록은 일시적이다. 사용자가 특정 후보를 채택하면 해당 논문만 `paper-search`로 넘겨 PDF, Keep, 인덱스, `01-Papers/library/{slug}.json`에 등록한다. 기존 paper ID나 정규화한 제목과 중복인지 다시 확인한다.

날짜별 사용자가 지정한 선정 계획이 `03-Trends/daily/{YYYY-MM-DD}-plan.md`에 있으면 3개 슬롯의 주제 기준에 적용한다. 이 계획은 학회 게재 검증 조건을 낮추지 않는다.

## 예약 실행

저장소는 스킬 실행 절차만 정의한다. 매일 09:00 KST 예약은 Orca Automation에서 이 스킬을 호출하도록 설정한다. 자동화 프롬프트는 “오늘의 Daily Paper Candidates 3편을 검색해 채팅으로만 보고하고 파일을 수정하지 말 것”을 포함한다. 예약 생성·변경은 명시적인 사용자 요청이 있을 때만 수행한다.
